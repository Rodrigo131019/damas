﻿namespace juego_de_damas
{
    public partial class Form1 : Form
    {
        private Button[,] tablero = new Button[8, 8];
        private int[,] matrizTablero = new int[8, 8];
        private Point? piezaSeleccionada = null;
        private int turnoJugador = 1;
        public Form1()
        {
            InitializeComponent();
            InicializarTablero();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void InicializarTablero()
        {
            tableroPanel.RowCount = 8;
            tableroPanel.ColumnCount = 8;
            tableroPanel.Controls.Clear(); // Limpia cualquier control existente en el TableLayoutPanel

            for (int fila = 0; fila < 8; fila++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Button celda = new Button();
                    celda.Dock = DockStyle.Fill;
                    celda.Tag = new Point(fila, col);
                    celda.Click += Celda_Click;

                    // Alternar colores de las celdas
                    if ((fila + col) % 2 == 0)
                        celda.BackColor = Color.White;
                    else
                        celda.BackColor = Color.Gray;

                    tableroPanel.Controls.Add(celda, col, fila);
                    tablero[fila, col] = celda;

                    // Inicializar las piezas de juego
                    if (fila < 3 && (fila + col) % 2 != 0)
                        matrizTablero[fila, col] = 1; // Piezas del jugador 1
                    else if (fila > 4 && (fila + col) % 2 != 0)
                        matrizTablero[fila, col] = 2; // Piezas del jugador 2
                    else
                        matrizTablero[fila, col] = 0;
                }
            }

            ActualizarTablero(); // Actualizar el tablero al final, después de crear todas las celdas
        }
        private void ActualizarTablero()
        {
            for (int fila = 0; fila < 8; fila++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if (matrizTablero[fila, col] == 1)
                    {
                        tablero[fila, col].Text = "⬤"; // Jugador 1
                        tablero[fila, col].ForeColor = Color.Red; // Color rojo para jugador 1
                    }
                    else if (matrizTablero[fila, col] == 2)
                    {
                        tablero[fila, col].Text = "◯"; // Jugador 2
                        tablero[fila, col].ForeColor = Color.Blue; // Color azul para jugador 2
                    }
                    else if (matrizTablero[fila, col] == 3)
                    {
                        tablero[fila, col].Text = "⬤"; // Dama de jugador 1
                        tablero[fila, col].ForeColor = Color.DarkRed; // Color rojo oscuro para dama de jugador 1
                    }
                    else if (matrizTablero[fila, col] == 4)
                    {
                        tablero[fila, col].Text = "◯"; // Dama de jugador 2
                        tablero[fila, col].ForeColor = Color.DarkBlue; // Color azul oscuro para dama de jugador 2
                    }
                    else
                    {
                        tablero[fila, col].Text = ""; // Casilla vacía
                        tablero[fila, col].ForeColor = Color.Black; // Restablecer color si está vacío
                    }
                }
            }
        }

        private void Celda_Click(object sender, EventArgs e)
        {
            Button botonClicado = sender as Button;
            Point pos = (Point)botonClicado.Tag;
            int fila = pos.X;
            int col = pos.Y;

            if (piezaSeleccionada == null)
            {
                // Seleccionar pieza si es del jugador actual
                if ((turnoJugador == 1 && (matrizTablero[fila, col] == 1 || matrizTablero[fila, col] == 3)) ||
                    (turnoJugador == 2 && (matrizTablero[fila, col] == 2 || matrizTablero[fila, col] == 4)))
                {
                    piezaSeleccionada = pos;
                }
            }
            else
            {
                // Intentar mover la pieza seleccionada
                Point origen = piezaSeleccionada.Value;
                int pieza = matrizTablero[origen.X, origen.Y];
                if (MovimientoValido(origen, pos))
                {
                    // Mover pieza
                    matrizTablero[pos.X, pos.Y] = pieza;
                    matrizTablero[origen.X, origen.Y] = 0;

                    // Convertir en dama si llega al otro lado
                    if (turnoJugador == 1 && pos.X == 7) matrizTablero[pos.X, pos.Y] = 3;
                    else if (turnoJugador == 2 && pos.X == 0) matrizTablero[pos.X, pos.Y] = 4;

                    // Cambio de turno
                    turnoJugador = (turnoJugador == 1) ? 2 : 1;
                    piezaSeleccionada = null;
                    ActualizarTablero();
                }
            }
        }
        private bool MovimientoValido(Point origen, Point destino)
        {
            int pieza = matrizTablero[origen.X, origen.Y];
            int dx = destino.X - origen.X;
            int dy = destino.Y - origen.Y;

            // Verificar si el destino es una casilla vacía
            if (matrizTablero[destino.X, destino.Y] != 0) return false;

            // Movimientos básicos
            if (Math.Abs(dx) == 1 && Math.Abs(dy) == 1)
            {
                // Movimiento simple en diagonal
                if ((pieza == 1 && dx == 1) || (pieza == 2 && dx == -1) || pieza > 2)
                    return true;
            }
            else if (Math.Abs(dx) == 2 && Math.Abs(dy) == 2)
            {
                // Captura de pieza
                int medioX = origen.X + dx / 2;
                int medioY = origen.Y + dy / 2;
                int piezaCapturada = matrizTablero[medioX, medioY];

                if ((turnoJugador == 1 && (piezaCapturada == 2 || piezaCapturada == 4)) ||
                    (turnoJugador == 2 && (piezaCapturada == 1 || piezaCapturada == 3)))
                {
                    matrizTablero[medioX, medioY] = 0; // Capturar pieza
                    return true;
                }
            }

            return false;
        }
    }
}
